/*
 * file.h
 *
 *  Created on: 23. Feb. 2017
 *      Author: Bernd
 */

#ifndef FILE_H_
#define FILE_H_

void initItm();
int __io_putchar(int ch);

#endif /* FILE_H_ */
